@extends('front-end.layouts.master')

@section('content')


    <!--Main Slider-->
    <section class="main-slider">
        <div class="tp-banner-container">
            <div class="tp-banner">
                <ul> 
                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="{!! asset('public/frontend/images/main-slider/1.jpg') !!}"  data-saveperformance="off"  data-title="Awesome Title Here">
                        <img src="{!! asset('public/frontend/images/main-slider/1.jpg') !!}" alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">                  
                        <div class="tp-caption sft sfb tp-resizeme"
                        data-x="left" data-hoffset="15"
                        data-y="center" data-voffset="-125"
                        data-speed="1500"
                        data-start="0"
                        data-easing="easeOutExpo"
                        data-splitin="none"
                        data-splitout="none"
                        data-elementdelay="0.01"
                        data-endelementdelay="0.3"
                        data-endspeed="1200"
                        data-endeasing="Power4.easeIn">
                            <div class="countdown-box left-side">
                                <div class="countdown-timer">
                                    <div class="countdown-container">
                                        <div class="default-coundown">
                                            <div class="countdown time-countdown" data-countdown-time="2017/03/20"></div>
                                        </div>                       
                                    </div>                           
                                </div>
                            </div>
                        </div> 
                        <div class="tp-caption sft sfb tp-resizeme"
                        data-x="left" data-hoffset="15"
                        data-y="center" data-voffset="0"
                        data-speed="1500"
                        data-start="0"
                        data-easing="easeOutExpo"
                        data-splitin="none"
                        data-splitout="none"
                        data-elementdelay="0.01"
                        data-endelementdelay="0.3"
                        data-endspeed="1200"
                        data-endeasing="Power4.easeIn">
                            <h5>February 22, 2017</h5>
                        </div>
                        <div class="tp-caption sft sfb tp-resizeme"
                        data-x="left" data-hoffset="15"
                        data-y="center" data-voffset="50"
                        data-speed="1500"
                        data-start="0"
                        data-easing="easeOutExpo"
                        data-splitin="none"
                        data-splitout="none"
                        data-elementdelay="0.01"
                        data-endelementdelay="0.3"
                        data-endspeed="1200"
                        data-endeasing="Power4.easeIn">
                            <h1>Conference in Paris 2017</h1>
                        </div>                    
                        <div class="tp-caption sfb sfb tp-resizeme"
                        data-x="center" data-hoffset="-500"
                        data-y="center" data-voffset="150"
                        data-speed="1500"
                        data-start="100"
                        data-easing="easeOutExpo"
                        data-splitin="none"
                        data-splitout="none"
                        data-elementdelay="0.01"
                        data-endelementdelay="0.3"
                        data-endspeed="1200"
                        data-endeasing="Power4.easeIn">
                            <div class="link-btn">
                                <a href="#" class="btn-style-one">Register Now</a>
                            </div>
                        </div>
                        <div class="tp-caption sfb sfb tp-resizeme"
                            data-x="center" data-hoffset="-320"
                            data-y="center" data-voffset="150"
                            data-speed="1500"
                            data-start="500"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                            <div class="link-btn">
                                <a href="#" class="btn-style-two">Learn More</a>
                            </div>
                        </div>
                        <div class="tp-caption sfb sfb tp-resizeme"
                            data-x="right" data-hoffset="0"
                            data-y="top" data-voffset="100"
                            data-speed="1500"
                            data-start="500"
                            data-transform_idle="o:1;" 
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"   
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                            <div class="image-box">
                                <figure>
                                    <img src="{!! asset('public/frontend/images/main-slider/1.png') !!}" alt="">
                                </figure>
                            </div>
                        </div>
                    </li>
                    <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="{!! asset('public/frontend/images/main-slider/1.jpg') !!}"  data-saveperformance="off"  data-title="Awesome Title Here">
                        <img src="{!! asset('public/frontend/images/main-slider/1.jpg') !!}"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">                  
                        <div class="tp-caption sft sfb tp-resizeme"
                        data-x="right" data-hoffset="-15"
                        data-y="center" data-voffset="-125"
                        data-speed="1500"
                        data-start="0"
                        data-easing="easeOutExpo"
                        data-splitin="none"
                        data-splitout="none"
                        data-elementdelay="0.01"
                        data-endelementdelay="0.3"
                        data-endspeed="1200"
                        data-endeasing="Power4.easeIn">
                            <div class="countdown-box right-side">
                                <div class="countdown-timer">
                                    <div class="countdown-container">
                                        <div class="default-coundown">
                                            <div class="countdown time-countdown" data-countdown-time="2017/03/20"></div>
                                        </div>                       
                                    </div>                           
                                </div>
                            </div>
                        </div> 
                        <div class="tp-caption sft sfb tp-resizeme"
                        data-x="right" data-hoffset="-15"
                        data-y="center" data-voffset="0"
                        data-speed="1500"
                        data-start="0"
                        data-easing="easeOutExpo"
                        data-splitin="none"
                        data-splitout="none"
                        data-elementdelay="0.01"
                        data-endelementdelay="0.3"
                        data-endspeed="1200"
                        data-endeasing="Power4.easeIn">
                            <h5>February 22, 2017</h5>
                        </div>
                        <div class="tp-caption sft sfb tp-resizeme"
                        data-x="right" data-hoffset="-15"
                        data-y="center" data-voffset="50"
                        data-speed="1500"
                        data-start="0"
                        data-easing="easeOutExpo"
                        data-splitin="none"
                        data-splitout="none"
                        data-elementdelay="0.01"
                        data-endelementdelay="0.3"
                        data-endspeed="1200"
                        data-endeasing="Power4.easeIn">
                            <h1>Conference in Paris 2017</h1>
                        </div>                    
                        <div class="tp-caption sfb sfb tp-resizeme"
                        data-x="center" data-hoffset="320"
                        data-y="center" data-voffset="150"
                        data-speed="1500"
                        data-start="500"
                        data-easing="easeOutExpo"
                        data-splitin="none"
                        data-splitout="none"
                        data-elementdelay="0.01"
                        data-endelementdelay="0.3"
                        data-endspeed="1200"
                        data-endeasing="Power4.easeIn">
                            <div class="link-btn">
                                <a href="#" class="btn-style-one">Register Now</a>
                            </div>
                        </div>
                        <div class="tp-caption sfb sfb tp-resizeme"
                            data-x="center" data-hoffset="500"
                            data-y="center" data-voffset="150"
                            data-speed="1500"
                            data-start="100"
                            data-easing="easeOutExpo"
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                            <div class="link-btn">
                                <a href="#" class="btn-style-two">Learn More</a>
                            </div>
                        </div>
                        <div class="tp-caption sfb sfb tp-resizeme"
                            data-x="left" data-hoffset="-80"
                            data-y="top" data-voffset="0"
                            data-speed="1500"
                            data-start="500"
                            data-transform_idle="o:1;" 
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"   
                            data-splitin="none"
                            data-splitout="none"
                            data-elementdelay="0.01"
                            data-endelementdelay="0.3"
                            data-endspeed="1200"
                            data-endeasing="Power4.easeIn">
                            <div class="image-box">
                                <figure>
                                    <img src="{!! asset('public/frontend/images/main-slider/1.png') !!}" alt="">
                                </figure>
                            </div>
                        </div>
                    </li>
               </ul>
            </div>
        </div>
    </section>
    <!--End Main Slider-->

    <!--about-section-->
    <section class="about-section" style="background-image: url('{{ asset('public/frontend/images/background/1.jpg') }}');">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-5 col-sm-12 col-xs-12">
                    <div class="icon-holder">
                        <div class="item text-center">
                            <a href="#"><i class="fa fa-calendar" aria-hidden="true"></i></a>
                            <h6>22 - 25 Feb, 17</h6>
                        </div>
                        <div class="item text-center">
                            <a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i></a>
                            <h6>Canada</h6>
                        </div>
                        <div class="item text-center">
                            <a href="#"><i class="fa fa-sitemap" aria-hidden="true"></i></a>
                            <h6>500 Seats</h6>
                        </div>
                        <div class="item text-center">
                            <a href="#"><i class="fa fa-microphone" aria-hidden="true"></i></a>
                            <h6>50 Speakers</h6>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 col-md-7 col-sm-12 col-xs-12">
                    <div class="content-text">
                        <h3>Business<br><span>Conference</span> 2017</h3>
                        <h6>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco.</h6>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmtempor incididunt ut labore et dolore magna aliqu enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea.</p>
                        <div class="link-btn">
                            <a href="#" class="btn-style-one">Buy Ticket</a><a href="#" class="btn-style-two">read more</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End about-section-->

    <!--speaking-section-->
    <section class="speaking-section" style="background: url('{{ asset('public/frontend/images/background/2.jpg') }}');">
        <div class="container">
            <div class="section-title text-center">
                <h3>Who <span>Speaking?</span></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore <br>dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco.</p>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="image-holder text-center">
                        <div class="image-box">
                            <figure>
                                <img src="{!! asset('public/frontend/images/resource/1.jpg') !!}" alt="">
                            </figure>
                            <div class="overly-box">
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                            </div>                                                      
                        </div>
                        <div class="image-content">
                            <a href="speaker-details.html"><h5>Jonathan Franco</h5></a>
                            <span>Project Manager</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="image-holder text-center">
                        <div class="image-box">
                            <figure>
                                <img src="{!! asset('public/frontend/images/resource/2.jpg') !!}" alt="">
                            </figure>
                            <div class="overly-box">
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                            </div>                                                      
                        </div>
                        <div class="image-content">
                            <a href="speaker-details.html"><h5>Jonathan Franco</h5></a>
                            <span>Project Manager</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="image-holder text-center">
                        <div class="image-box">
                            <figure>
                                <img src="{!! asset('public/frontend/images/resource/3.jpg') !!}" alt="">
                            </figure>
                            <div class="overly-box">
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                            </div>                                                      
                        </div>
                        <div class="image-content">
                            <a href="speaker-details.html"><h5>Jonathan Franco</h5></a>
                            <span>Project Manager</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="image-holder text-center">
                        <div class="image-box">
                            <figure>
                                <img src="{!! asset('public/frontend/images/resource/4.jpg') !!}" alt="">
                            </figure>
                            <div class="overly-box">
                                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                                <li><a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a></li>
                            </div>                                                      
                        </div>
                        <div class="image-content">
                            <a href="speaker-details.html"><h5>Jonathan Franco</h5></a>
                            <span>Project Manager</span>
                        </div>
                    </div>
                </div>
            </div>                
        </div>
    </section>
    <!--speaking-section-->

    <!--schedule-section-->
    <section class="schedule-section" id="schedule-tab" style="background-image: url('{{ asset('public/frontend/images/background/3.jpg') }}');">
        <div class="container">
            <div class="section-title text-center">
                <h3>Event <span>Schedule</span></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore <br>dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco.</p>
            </div>
            <div class="schedule-area">
                <div class="schedule-tab-title">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <tbody>
                                <tr>
                                    <td class="item active" data-tab-name="monday">
                                        <div class="item-text">
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                            <h5>Monday</h5>
                                            <h6>feb 20, 2017</h6>
                                        </div>
                                    </td>
                                    <td class="item" data-tab-name="tuesday">
                                        <div class="item-text">
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                            <h5>Tuesday</h5>
                                            <h6>feb 20, 2017</h6>
                                        </div>                                            
                                    </td>
                                    <td class="item" data-tab-name="wednesday">
                                        <div class="item-text text-less">
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                            <h5>Wednesday</h5>
                                            <h6>feb 20, 2017</h6>
                                        </div>                                            
                                    </td>
                                    <td class="item" data-tab-name="thursday">
                                        <div class="item-text">
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                            <h5>Thursday</h5>
                                            <h6>feb 20, 2017</h6>
                                        </div>                                            
                                    </td>
                                    <td class="item" data-tab-name="friday">
                                        <div class="item-text">
                                            <i class="fa fa-calendar" aria-hidden="true"></i>
                                            <h5>Friday</h5>
                                            <h6>feb 20, 2017</h6>
                                        </div>                                            
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>            
                </div>
                <div class="schedule-tab-content clearfix">
                    <div id="monday">
                        <div class="inner-box  table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Speaker</th>
                                        <th>Subject</th>
                                        <th>Venue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 9.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/1.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Samanta Doe</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>                            
                                        <td class="venue">Auditorium A</td>
                                    </tr>
                                    <tr class="row-color">
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 10.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/2.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Zerad Pawel</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Principle of Wp</td>
                                        <td class="venue">Auditorium B</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 12.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/3.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Henri Mong</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Wp Requirements</td>
                                        <td class="venue">Auditorium C</td>
                                    </tr>
                                    <tr class="row-color">
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 2.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/4.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Baily Lio</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 3.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/5.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Lee Mun</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Useful Tips for Wp</td>
                                        <td class="venue">Auditorium E</td>
                                    </tr>
                                    <tr class="row-color">
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 4.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/6.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Rickey Wen</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Plugin Development</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div id="tuesday">
                        <div class="inner-box table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Speaker</th>
                                        <th>Subject</th>
                                        <th>Venue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 9.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/1.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Samanta Doe</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>                            
                                        <td class="venue">Auditorium A</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 10.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/2.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Zerad Pawel</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Principle of Wp</td>
                                        <td class="venue">Auditorium B</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 12.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/3.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Henri Mong</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Wp Requirements</td>
                                        <td class="venue">Auditorium C</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 2.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/4.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Baily Lio</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 3.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/5.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Lee Mun</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Useful Tips for Wp</td>
                                        <td class="venue">Auditorium E</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 4.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/6.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Rickey Wen</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Plugin Development</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div id="wednesday">
                        <div class="inner-box table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Speaker</th>
                                        <th>Subject</th>
                                        <th>Venue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 9.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/1.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Samanta Doe</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>                            
                                        <td class="venue">Auditorium A</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 10.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/2.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Zerad Pawel</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Principle of Wp</td>
                                        <td class="venue">Auditorium B</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 12.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/3.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Henri Mong</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Wp Requirements</td>
                                        <td class="venue">Auditorium C</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 2.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/4.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Baily Lio</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 3.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/5.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Lee Mun</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Useful Tips for Wp</td>
                                        <td class="venue">Auditorium E</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 4.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/6.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Rickey Wen</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Plugin Development</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div id="thursday">
                        <div class="inner-box table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Speaker</th>
                                        <th>Subject</th>
                                        <th>Venue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 9.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/1.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Samanta Doe</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>                            
                                        <td class="venue">Auditorium A</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 10.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/2.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Zerad Pawel</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Principle of Wp</td>
                                        <td class="venue">Auditorium B</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 12.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/3.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Henri Mong</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Wp Requirements</td>
                                        <td class="venue">Auditorium C</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 2.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/4.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Baily Lio</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 3.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/5.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Lee Mun</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Useful Tips for Wp</td>
                                        <td class="venue">Auditorium E</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 4.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/6.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Rickey Wen</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Plugin Development</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div id="friday">
                        <div class="inner-box table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Speaker</th>
                                        <th>Subject</th>
                                        <th>Venue</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 9.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/1.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Samanta Doe</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>                            
                                        <td class="venue">Auditorium A</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 10.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/2.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Zerad Pawel</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Principle of Wp</td>
                                        <td class="venue">Auditorium B</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 12.00 AM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/3.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Henri Mong</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Wp Requirements</td>
                                        <td class="venue">Auditorium C</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 2.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/4.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Baily Lio</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Inroduction to Wp</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 3.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box">
                                                    <img src="{!! asset('public/frontend/images/resource/5.png') !!}" alt="">
                                                </div>
                                                <h4><a href="speaker-details.html">Lee Mun</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Useful Tips for Wp</td>
                                        <td class="venue">Auditorium E</td>
                                    </tr>
                                    <tr>
                                        <td class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> 4.00 PM</td>
                                        <td class="speakers">
                                            <div class="speaker">
                                                <div class="image-box"><img src="{!! asset('public/frontend/images/resource/6.png') !!}" alt=""></div>
                                                <h4><a href="speaker-details.html">Rickey Wen</a></h4>
                                            </div>
                                        </td>
                                        <td class="subject">Plugin Development</td>
                                        <td class="venue">Auditorium D</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>                
        </div>
    </section>
    <!--End schedule-section-->

    <!--contact-us-->
    <section class="contact-us" style="background-image: url('{{ asset('public/frontend/images/background/11.jpg') }}');">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-12 col-xs-12">
                    <div class="default-form-area">
                        <div class="section-title">
                            <h3>Register to <span>Eventic Now</span></h3>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusm tempor</p>
                        </div>                            
                        <form id="contact-form" name="contact_form" class="default-form" action="http://html.tonatheme.com/2017/eventic_html/inc/sendmail.php" method="post" novalidate="novalidate">
                            <div class="row">
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="contact-area-left">
                                        <div class="form-group">
                                            <input type="text" placeholder="Your Name">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" placeholder="Phone">
                                        </div>
                                    </div>                               
                                </div>
                                <div class="col-md-6 col-sm-12 col-xs-12">
                                    <div class="contact-area-right">                                        
                                        <div class="form-group">
                                            <input type="email" placeholder="Email">
                                        </div>
                                        <div class="form-group">
                                            <select class="text-capitalize selectpicker form-control required" name="form_subject" data-style="g-select" data-width="100%">
                                                <option>Ticket Type</option>
                                                <option>Insurance</option>
                                                <option>Finance</option>
                                            </select>
                                        </div>
                                    </div>                                      
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group top-padd">
                                        <input id="form_botcheck" name="form_botcheck" class="form-control" type="hidden" value="">
                                        <button class="btn-style-one" type="submit" data-loading-text="Please wait...">send message</button>
                                    </div>
                                </div>
                            </div>                                        
                        </form>
                    </div>
                </div>
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="image-box">
                        <figure>
                            <img src="{!! asset('public/frontend/images/background/10.jpg') !!}" alt="">
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End contact-us-->

    <!--gellary-section-->
    <section class="gallery-section" style="background-image: url('{{ asset('public/frontend/images/background/4.jpg') }}');">
        <div class="container">
            <div class="section-title text-center">
                <h3>Event <span>Gallery</span></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore <br>dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco.</p>
            </div>
            <div class="row inner-container">
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="img_holder">
                            <img src="{{ asset('public/frontend/images/gallery/1.jpg') }}" alt="images" class="img-responsive">
                        </div>
                        <div class="overlay-box text-center">                       
                            <a href="images/gallery/1.jpg" class="fancybox"><i class="fa fa-picture-o" aria-hidden="true"></i></a>
                        </div> 
                    </div>                                           
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="img_holder">
                            <img src="{{ asset('public/frontend/images/gallery/2.jpg') }}" alt="images" class="img-responsive">
                        </div>
                        <div class="overlay-box text-center">
                            <a href="images/gallery/2.jpg" class="fancybox"><i class="fa fa-picture-o" aria-hidden="true"></i></a>
                        </div>  
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="img_holder">
                            <img src="{{ asset('public/frontend/images/gallery/3.jpg') }}" alt="images" class="img-responsive">
                        </div>
                        <div class="overlay-box text-center">
                            <a href="images/gallery/3.jpg" class="fancybox"><i class="fa fa-picture-o" aria-hidden="true"></i></a>
                        </div>  
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="img_holder">
                            <img src="{{ asset('public/frontend/images/gallery/4.jpg') }}" alt="images" class="img-responsive">
                        </div>
                        <div class="overlay-box text-center">
                            <a href="images/gallery/4.jpg" class="fancybox"><i class="fa fa-picture-o" aria-hidden="true"></i></a>
                        </div>  
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="img_holder">
                            <img src="{{ asset('public/frontend/images/gallery/5.jpg') }}" alt="images" class="img-responsive">
                        </div>
                        <div class="overlay-box text-center">
                            <a href="images/gallery/5.jpg" class="fancybox"><i class="fa fa-picture-o" aria-hidden="true"></i></a>
                        </div>  
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="inner-box">
                        <div class="img_holder">
                            <img src="{{ asset('public/frontend/images/gallery/6.jpg') }}" alt="images" class="img-responsive">
                        </div>
                        <div class="overlay-box text-center">
                            <a href="images/gallery/6.jpg" class="fancybox"><i class="fa fa-picture-o" aria-hidden="true"></i></a>
                        </div>  
                    </div>
                </div>
            </div>
            <div class="link-btn text-center">
                <a href="gallery.html" class="btn-style-one">read more</a>
            </div>
        </div>
    </section>
    <!--End gellary-section-->

    <!--sponsors section-->
    <div class="sponsors" style="background-image: url('{{ asset('public/frontend/images/background/5.jpg') }}');">
        <div class="container">
            <div class="section-title text-center">
                <h3>Event <span>Sponsors</span></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore <br>dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco.</p>
            </div>
            <div class="sponsors-logo text-center">
                <ul class="sponsors-five-cloumn">
                    <h6>Platinum Sponsors</h6>
                    <li>
                        <figure>
                            <a href="#"><img src="{{ asset('public/frontend/images/clients/1.png') }}" alt=""></a>
                        </figure>
                    </li>
                    <li>
                        <figure>
                            <a href="#"><img src="{{ asset('public/frontend/images/clients/2.png') }}" alt=""></a>
                        </figure>
                    </li>
                    <li>
                        <figure>
                            <a href="#"><img src="{{ asset('public/frontend/images/clients/3.png') }}" alt=""></a>
                        </figure>
                    </li>
                    <li>
                        <figure>
                            <a href="#"><img src="{{ asset('public/frontend/images/clients/4.png') }}" alt=""></a>
                        </figure>
                    </li>
                    <li>
                        <figure>
                            <a href="#"><img src="{{ asset('public/frontend/images/clients/5.png') }}" alt=""></a>
                        </figure>
                    </li>
                </ul>
                <ul class="sponsors-three-cloumn">
                    <h6>Gold Sponsors</h6>
                    <li>
                        <figure>
                            <a href="#"><img src="{{ asset('public/frontend/images/clients/6.png') }}" alt=""></a>
                        </figure>
                    </li>
                    <li>
                        <figure>
                            <a href="#"><img src="{{ asset('public/frontend/images/clients/7.png') }}" alt=""></a>
                        </figure>
                    </li>
                    <li>
                        <figure>
                            <a href="#"><img src="{{ asset('public/frontend/images/clients/8.png') }}" alt=""></a>
                        </figure>
                    </li>
                </ul>
                <div class="link-btn">
                    <a href="#" class="btn-style-one">Become A Sponsor</a>
                </div>
            </div>
        </div>
    </div>
    <!--End sponsors section-->

    <!--ticket-price section-->
    <section class="ticket-price" style="background-image: url('{{ asset('public/frontend/images/background/6.jpg') }}');">
        <div class="container">
            <div class="section-title text-center">
                <h3>Choose A <span>Plan</span></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore <br>dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco.</p>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xa-12">
                    <div class="price-item text-center">
                        <div class="colmun-title">
                            <h6>Starter</h6>
                        </div>
                        <div class="price-money">
                            <h1>49.00<span>$</span></h1>
                            <p>Per Person</p>
                        </div>
                        <ul class="catagory-list">
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>1 Comfortable Seats</li>
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>Free Lunch and Coffee</li>
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>Certificate</li>
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>Easy Access</li>
                        </ul>
                        <div class="link-btn">
                            <a href="#" class="btn-style-two">Buy A Ticket</a>
                        </div>                        
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xa-12">
                    <div class="price-item text-center">
                        <div class="colmun-title">
                            <h6>Standerd</h6>
                        </div>
                        <div class="price-money">
                            <h1>59.00<span>$</span></h1>
                            <p>Per Person</p>
                        </div>
                        <ul class="catagory-list">
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>1 Comfortable Seats</li>
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>Free Lunch and Coffee</li>
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>Certificate</li>
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>Easy Access</li>
                        </ul>
                        <div class="link-btn">
                            <a href="#" class="btn-style-two">Buy A Ticket</a>
                        </div>                        
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xa-12">
                    <div class="price-item text-center">
                        <div class="colmun-title">
                            <h6>Platinum</h6>
                        </div>
                        <div class="price-money">
                            <h1>79.00<span>$</span></h1>
                            <p>Per Person</p>
                        </div>
                        <ul class="catagory-list">
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>1 Comfortable Seats</li>
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>Free Lunch and Coffee</li>
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>Certificate</li>
                            <li><i class="fa fa-circle-thin" aria-hidden="true"></i>Easy Access</li>
                        </ul>
                        <div class="link-btn">
                            <a href="#" class="btn-style-two">Buy A Ticket</a>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End ticket-price section-->  

    <!--event-section-->
    <section class="event-section" style="background-image: url('{{ asset('public/frontend/images/background/7.jpg') }}');">
        <div class="container">
            <div class="section-title">
                <h3>Largest Event <span>Ever</span></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore <br>dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco.</p>
                <div class="link-btn">
                    <a href="#" class="btn-style-one">Purchase Now</a>
                </div>
            </div>
        </div>
    </section>
    <!--End event-section-->

    <!--news-section Style-->
    <section class="news-section" style="background-image: url('{{ asset('public/frontend/images/background/8.jpg') }}');">
        <div class="container">
            <div class="section-title text-center">
                <h3>Latest <span>News</span></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore <br>dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco.</p>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="image-holder">
                        <div class="image-box">
                            <figure>
                                <a href="blog-details.html"><img src="{{ asset('public/frontend/images/blog/1.jpg') }}" alt=""></a>
                            </figure>
                            <div class="date-box">
                                <h2>20</h2>
                                <span>February</span>
                            </div>
                        </div>                            
                        <div class="image-content">
                            <a href="blog-details.html"><h5>Nullam cursus lectus at fact.</h5></a>
                            <ul class="item-menu">
                                <li>by <span>Admin</span></li>
                                <li>Business</li>
                                <li>Comts <span>(05)</span></li>
                            </ul>    
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="image-holder">
                        <div class="image-box">
                            <figure>
                                <a href="blog-details.html"><img src="{{ asset('public/frontend/images/blog/2.jpg') }}" alt=""></a>
                            </figure>
                            <div class="date-box">
                                <h2>20</h2>
                                <span>February</span>
                            </div>
                        </div>                            
                        <div class="image-content">
                            <a href="blog-details.html"><h5>Cras sed ligula luctus tincid.</h5></a>
                            <ul class="item-menu">
                                <li>by <span>Admin</span></li>
                                <li>Business</li>
                                <li>Comts <span>(05)</span></li>
                            </ul>    
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-12">
                    <div class="image-holder">
                        <div class="image-box">
                            <figure>
                                <a href="blog-details.html"><img src="{{ asset('public/frontend/images/blog/3.jpg') }}" alt=""></a>
                            </figure>
                            <div class="date-box">
                                <h2>20</h2>
                                <span>February</span>
                            </div>
                        </div>                            
                        <div class="image-content">
                            <a href="blog-details.html"><h5>Elit accumsan egestas velit.</h5></a>
                            <ul class="item-menu">
                                <li>by <span>Admin</span></li>
                                <li>Business</li>
                                <li>Comts <span>(05)</span></li>
                            </ul>    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End news-section Style-->

    <!--Start Google map area-->
    <section class="google-map-area">
        <div class="container-fullwidth">
            <div 
                class="google-map"
                id="contact-google-map" 
                data-map-lat="45.717052" 
                data-map-lng="11.359770" 
                data-icon-path="{{ asset('public/frontend/images/resource/map-marker.png') }}" 
                data-map-title="Sheridan School Special Education" 
                data-map-zoom="12"
                data-markers='{
                    "marker-1": [45.717052, 11.359770, "<h4>Sheridan School Special Education</h4><p>201 N Connor St Sheridan, WY 82801</p>","{{ asset('public/frontend/images/resource/map-marker.png') }}"]
                }'>

            </div>                    
        </div>               
    </section>
    <!--End Google map area--> 

    <!-- map-content section -->
    <section class="map-content">
        <div class="container">
            <div class="content-text">
                <h4>Location</h4>
                <p>Lorem ipsum dolor sit amet, consectetur <br>adipisicing elit sed.</p>
                <h5>Docklands Convention</h5>
                <div class="contact-link">
                    <div class="item">
                        <i class="fa fa-home" aria-hidden="true"></i>
                        <h6>1201 Park Street, Fifth Avenue,<br>Dhanmondy, Dhaka.</h6>
                    </div>
                    <div class="item">
                        <i class="fa fa-phone" aria-hidden="true"></i>
                        <h6>[88] 657 524 332</h6>
                    </div>
                    <div class="link-btn">
                        <a href="#" class="btn-style-two">Get Direction</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End map-content section -->     


@stop