
<script src="{!! asset('public/frontend/js/jquery.js')!!}"></script>
<script type="text/javascript" src="{!! asset('public/frontend/js/jquery-2.1.4.js')!!}"></script> 
<script src="{!! asset('public/frontend/js/bootstrap.min.js')!!}"></script>
<script src="{!! asset('public/frontend/js/bootstrap-select.min.js')!!}"></script>
<script type="text/javascript" src="{!! asset('public/frontend/js/jquery-ui.min.js')!!}"></script>
<script src="{!! asset('public/frontend/js/revolution.min.js')!!}"></script>
<script src="{!! asset('public/frontend/js/jquery.themepunch.tools.min.js')!!}"></script>
<script src="{!! asset('public/frontend/js/isotope.js')!!}"></script>
<script src="{!! asset('public/frontend/js/jquery.fancybox.pack.js')!!}"></script>
<script src="{!! asset('public/frontend/js/jquery.fancybox-media.js')!!}"></script>
<script src="{!! asset('public/frontend/js/html5lightbox.js')!!}"></script>
<script src="{!! asset('public/frontend/js/owl.js')!!}"></script>
<script type="text/javascript" src="{!! asset('public/frontend/js/jquery.mixitup.min.js')!!}"></script>
<script src="{!! asset('public/frontend/js/owl.carousel.min.js')!!}"></script>
<script src="{!! asset('public/frontend/js/mixitup.js')!!}"></script>
<script src="{!! asset('public/frontend/js/validate.js')!!}"></script>
<script src="{!! asset('public/frontend/js/wow.js')!!}"></script>
<script src="{!! asset('public/frontend/js/jquery.appear.js')!!}"></script>
<script src="{!! asset('public/frontend/js/jquery.countTo.js')!!}"></script>
<script src="{!! asset('public/frontend/js/jquery.countdown.min.js')!!}"></script>
<script src="{!! asset('public/frontend/js/jquery.counterup.min.js')!!}"></script>

<!-- gmap helper -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAHzPSV2jshbjI8fqnC_C4L08ffnj5EN3A"></script>
<!--gmap script-->
<script src="{!! asset('public/frontend/js/gmaps.js')!!}"></script>
<script src="{!! asset('public/frontend/js/map-helper.js')!!}"></script>


<script src="{!! asset('public/frontend/js/script.js')!!}"></script>
@yield('customJs')
