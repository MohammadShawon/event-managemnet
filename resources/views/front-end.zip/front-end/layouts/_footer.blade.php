
<!--subscribe-section Style-->
    <section class="subscribe-section" style="background-image: url('{{ asset('public/frontend/images/background/9.jpg') }}');">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <div class="section-title">
                        <h3>Subscribe to Our <span>Newsletter</span></h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusm tempor</p>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                    <form method="post" action="http://html.tonatheme.com/2017/eventic_html/index.html" class="subscribe-form">
                        <div class="form-group">
                            <input type="email" name="useremail" value="" placeholder="Enter your email" required="">
                            <button type="submit" class="btn-style-one">subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!--End subscribe-section Style-->


    <!--Main Footer-->
    <footer class="main-footer">
    	<div class="small-container text-center">
            <div class="footer-logo">
                <figure>
                    <a href="index-2.html"><img src="{!! asset('public/frontend/images/logo-2.png')!!}" alt=""></a>
                </figure>
            </div>
            <ul class="links-menu">
                <li><a href="#">Home</a></li>
                <li><a href="#">Speakers</a></li>
                <li><a href="#">Pages</a></li>
                <li><a href="#">Schedule</a></li>
                <li><a href="#">Sponsors</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
            <ul class="social-links">
                <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-rss" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-vimeo" aria-hidden="true"></i></a></li>
            </ul>      
        </div>        
        <!--Footer Bottom-->
        <div class="footer-bottom">
        	<div class="container">
                <div class="text-center footer-text"><p>Eventic &copy;  2017 All Right Reserved</p></div>
            </div>            
        </div>         
    </footer>
    <!--Main Footer-->
